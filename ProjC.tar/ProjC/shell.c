int strCompare(char*, char*);

void main()
{
	char line[11];
	char* type = "type\0";
	char* exec = "exec\0";
	char buffer[13312];
	int sectorsRead = 0; 

	int x = 1 ;
	while (x == 1)
	{
		syscall(0, "SHELL> ");

		syscall(1, line);

		if (strCompare(line, type) == 1)
		{
			syscall(3, line+5, buffer, &sectorsRead);
			if (sectorsRead == 0)
			{
				syscall(0, "File Not Found. \r\n");
			}
			else
			{
				syscall(0, buffer);
				syscall(0, "\r\n");
				syscall(5);
			}
		}
		else if (strCompare(line, exec) == 1)
		{
			syscall(4, line+5);
			*(line + 5) = '\0';
			syscall(5);
		}
		else
		{
			syscall(0, "Bad command \r\n");
		}
		
		//syscall(0, line);

		//syscall(0, "FATAL! :( \r\n");
	}

}
int strCompare(char* line, char* command) //returns 0 if not same, 1 if same
{
	int i;
	for(i = 0; i<4; i++)
	{
		if(line[i] != command[i])
		{
			//interrupt(0x21, 0, "File name NOT found in dir\r\n", 0, 0);
			return 0;
		}
		if (line[i] == '\0')
		{
			//interrupt(0x21, 0, "File name found in dir\r\n", 0, 0);
			return 1;
		}
	}

	//interrupt(0x21, 0, "File name found in dir at end of loop returning\r\n", 0, 0);
	return 1;
}