

void int main()
{
	makeInterrupt21();
}