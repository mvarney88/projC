//tstpr2.c

main()
{
	syscall(0,"tstpr2 is working!\r\n");
	syscall(5);
	while(1);
}
