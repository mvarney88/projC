void printString(char*);
void readString(char*);
void readSector(char*, int);
void handleInterrupt21(int, int, int, int);
void readFile(char*, char*, int*);
int strCompare(char*, char*);
void executeProgram(char*);
void terminate();


void main()
{
	int sectorsRead = 0;
	char buffer[13312];
	//readFile("messag", buffer, &sectorsRead);
	makeInterrupt21();
	interrupt(0x21, 3, "messag", buffer, &sectorsRead);
	if (sectorsRead > 0)
	{
		interrupt(0x21, 0, buffer, 0, 0); //print out the file
	}
	else
	{
		interrupt(0x21, 0, "messag not found\r\n", 0, 0); //no sectors reads
	}
	makeInterrupt21();
	interrupt(0x21, 4, "tstpr2", 0,0);
	//interrupt(0x21, 4, "tstpr1", 0,0);
	makeInterrupt21();
	interrupt(0x21, 5,0,0,0);
//	char line[80];
//	printString("Enter a line: \0");
//	makeInterrupt21();
//	interrupt(0x21,1,line,0,0);
//	interrupt(0x21,0,line,0,0);
//	readSector(buffer,30);
//	printString(buffer);
//	readFile(buffer, char* name, &sectorsRead);

	while(1);
}
int strCompare(char* name, char* dir) //returns 0 if not same, 1 if same
{
	int i;
	for(i = 0; i<6; i++)
	{
		if(name[i] != dir[i])
		{
			//interrupt(0x21, 0, "File name NOT found in dir\r\n", 0, 0);
			return 0;
		}
		if (name[i] == '\0')
		{
			//interrupt(0x21, 0, "File name found in dir\r\n", 0, 0);
			return 1;
		}
	}

	//interrupt(0x21, 0, "File name found in dir at end of loop returning\r\n", 0, 0);
	return 1;
}
void terminate()
{
	int x = 1;
	interrupt(0x10, 0xe*256+'A', 0, 0, 0);
	while (x==1)
  	{

  	}
}
void executeProgram(char* name)
{
	int i;
	char buffer[13312];
	int sectorsRead;
	//interrupt(0x21, 0, "In executeProgram\r\n", 0,0);
	readFile(name, buffer, &sectorsRead);

	for (i = 0; i < 13312; i++)
	{
		putInMemory(0x2000, i, buffer[i]);
	}

	launchProgram(0x2000);
}
void readFile(char* name, char* buffer, int* sectors)
{
	int sector;
	int result;
	int s;
	int i;
	//*sectors = 0;
	char dir[512];
	readSector(dir, 2); //reads in sector 2(directory

	for (i = 0; i<512; i = i+32)
	{
		result = strCompare(name, dir+i);
		if (result == 1)
		{

			for(s = i+6; s < i+6+26; s++)
			{
				sector = dir[s];
				readSector(buffer, sector);
				buffer = buffer + 512;
				*sectors = *sectors+1;
			}
		}
	}

	//int ax = 3;
	//int bx = line;
	//int cx = buffer;
	//int dx = 2;
	//makeInterrupt21();
	//interrupt(0x21,ax,bx,cx,dx);
}

void handleInterrupt21(int ax, int bx, int cx, int dx)
{
	if(ax == 0)
	{
		printString(bx);
	}
	else if(ax == 1)
	{
		readString(bx);
	}
	else if(ax ==2)
	{
		readSector(bx,cx);
	}
	else if (ax == 3)
	{
		//interrupt(0x10, "Trying to run ReadFile", 0, 0, 0);
		readFile(bx,cx,dx);
	}
	else if (ax == 4)
	{
		executeProgram(bx);
	}
	else if (ax == 5)
	{
		terminate();
	}
	else
	{
		printString("Error! \0");
	}
}
void readSector(char* buffer,int sector)
{
	int ah = 2;
	int al = 1;
	int bx = buffer;
	int ch = 0;
	int cl = sector +1;
	int dh = 0;
	int dl = 0x80;
	int ax = ah*256+al;
	int cx = ch*256+cl;
	int dx = dh*256 +dl;

	interrupt(0x13,ax,bx,cx,dx);
}
void printString(char* chars)
{
	int c = 0;
	while(chars[c]!=0)
	{
		char al  = chars[c];
		char ah = 0xe;
		int ax = ah*256+al;
		interrupt(0x10, ax, 0, 0, 0);
		c++;
	}
}
void readString(char* line)
{
	char in = 0;
	int start = 0;
	while(in != '\r')
	{
		in = interrupt(0x16, 0);
		if(in =='\b' && start > 0)
		{
			*(line-1) = in;
			interrupt(0x10, 0xe * 256 + '\b', 0, 0, 0);
			interrupt(0x10, 0xe * 256 + ' ', 0, 0, 0);
			interrupt(0x10, 0xe * 256 + '\b', 0, 0, 0);
			line--;
			start--;
		}

		else if (in != '\b')
		{
			*line = in;
			interrupt(0x10, 0xe * 256 + *line, 0, 0, 0);
			line++;
			start++;
		}
	}
	*line = '\n';
	interrupt(0x10, 0xe*256+*line, 0 ,0 ,0);
	line++;
	*line = '\0';
}
